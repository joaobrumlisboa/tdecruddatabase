<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $delete = "DELETE FROM Pessoa WHERE id = $id";
    
    if ($conn->query($delete) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Erro ao excluir: " . $conn->error;
    }
}
?>
