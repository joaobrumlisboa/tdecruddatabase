<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM Cor_favorita WHERE id = $id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $cor = $result->fetch_assoc();
    } else {
        die("Cor não encontrada.");
    }
} else {
    die("ID da cor não especificado.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome_cor = $_POST['nome_cor'];

    $sqlUpdate = "UPDATE Cor_favorita SET nome = '$nome_cor' WHERE id = $id";
    if ($conn->query($sqlUpdate) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Erro ao atualizar cor: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Cor Favorita</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { margin-top: 20px; }
        input[type="text"] { padding: 10px; width: 200px; margin-bottom: 10px; }
        input[type="submit"] { background-color: #4CAF50; color: white; border: none; padding: 10px 20px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #45a049; }
        a { text-decoration: none; color: #007BFF; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h1>Editar Cor Favorita</h1>
    <form method="POST">
        <label for="nome_cor">Nome da Cor:</label>
        <input type="text" name="nome_cor" value="<?php echo htmlspecialchars($cor['nome']); ?>" required><br>

        <input type="submit" value="Salvar">
    </form>
    <a href="index.php">Voltar</a>
</body>
</html>
