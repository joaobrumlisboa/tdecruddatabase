<?php
include 'db.php';

$cores = "SELECT * FROM Cor_favorita";
$resultcores = $conn->query($cores);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $cor_favorita_id = $_POST['cor_favorita'];
    $cpf = $_POST['cpf'];

    $sqlInsert = "INSERT INTO Pessoa (cpf, nome, fk_Cor_favorita_id) VALUES ($cpf, '$nome', $cor_favorita_id)";
    if ($conn->query($sqlInsert) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Erro ao adicionar: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Pessoa</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { margin-top: 20px; }
        input[type="text"], select { padding: 10px; margin-bottom: 10px; }
        input[type="submit"] { background-color: #4CAF50; color: white; border: none; padding: 10px 20px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #45a049; }
        a { text-decoration: none; color: #007BFF; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h1>Adicionar Pessoa</h1>
    <form method="POST">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" required><br>

        <label for="cpf">CPF:</label>
        <input type="text" name="cpf" required><br>

        <label for="cor_favorita">Cor Favorita:</label>
        <select name="cor_favorita">
            <?php while($cor = $resultcores->fetch_assoc()) { ?>
                <option value="<?php echo $cor['id']; ?>"><?php echo $cor['nome']; ?></option>
            <?php } ?>
        </select><br>

        <input type="submit" value="Adicionar">
    </form>
    <a href="index.php">Voltar</a>
</body>
</html>
