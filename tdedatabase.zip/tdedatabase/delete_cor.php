<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sqlCheckUsage = "SELECT * FROM Pessoa WHERE fk_Cor_favorita_id = $id";
    $checkResult = $conn->query($sqlCheckUsage);

    if ($checkResult->num_rows > 0) {
        echo "Cor associada a uma ou mais pessoas.";
    } else {
        $sqlDelete = "DELETE FROM Cor_favorita WHERE id = $id";
        if ($conn->query($sqlDelete) === TRUE) {
            header("Location: index.php");
            exit;
        } else {
            echo "Erro ao excluir cor: " . $conn->error;
        }
    }
} else {
    die("ID da cor não especificado.");
}
?>
