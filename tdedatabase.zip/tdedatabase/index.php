<?php
include 'db.php';

$sql = "SELECT Pessoa.id, Pessoa.nome, Pessoa.cpf, Cor_favorita.nome AS cor, Cor_favorita.id AS cor_id FROM Pessoa
        LEFT JOIN Cor_favorita ON Pessoa.fk_Cor_favorita_id = Cor_favorita.id";
$result = $conn->query($sql);

$cor = "SELECT * FROM Cor_favorita";
$resultcor = $conn->query($cor);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>CRUD de Pessoas</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 60%; border-collapse: collapse; margin: 20px 0; }
        table, th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f2f2f2; }
        a { text-decoration: none; color: #007BFF; }
        a:hover { text-decoration: underline; }
        input[type="submit"] { background-color: #4CAF50; color: white; border: none; padding: 10px 20px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #45a049; }
        .actions a { margin-right: 10px; }
        .actions { text-align: center; }
        h1 { margin-bottom: 20px; }
        .action-links { margin-top: 20px; }
    </style>
</head>
<body>
    <h1>Lista de Pessoas</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>CPF</th>
            <th>Cor Favorita</th>
            <th>Ações</th>
        </tr>
        <?php while($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['nome']; ?></td>
                <td><?php echo $row['cpf']; ?></td>
                <td><?php echo $row['cor']; ?></td>
                <td class="actions">
                    <a href="update.php?id=<?php echo $row['id']; ?>">Editar</a>
                    <a href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <h2>Cores Favoritas</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Ações</th>
        </tr>
        <?php while($cor = $resultcor->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $cor['id']; ?></td>
                <td><?php echo $cor['nome']; ?></td>
                <td class="actions">
                    <a href="update_cor.php?id=<?php echo $cor['id']; ?>">Editar</a>
                    <a href="delete_cor.php?id=<?php echo $cor['id']; ?>" onclick="return confirm('Tem certeza que deseja excluir esta cor?')">Excluir</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <div class="action-links">
        <a href="create.php">Adicionar Pessoa</a> |
        <a href="create_cor.php">Adicionar Cor</a>
    </div>
</body>
</html>