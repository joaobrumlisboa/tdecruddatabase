<?php
include 'db.php';

// Adiciona uma nova cor
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome_cor = $_POST['nome_cor'];

    $sqlInsert = "INSERT INTO Cor_favorita (nome) VALUES ('$nome_cor')";
    if ($conn->query($sqlInsert) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Erro ao adicionar cor: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Cor Favorita</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { margin-top: 20px; }
        input[type="text"] { padding: 10px; width: 200px; margin-right: 10px; }
        input[type="submit"] { background-color: #4CAF50; color: white; border: none; padding: 10px 20px; cursor: pointer; }
        input[type="submit"]:hover { background-color: #45a049; }
        a { text-decoration: none; color: #007BFF; }
    </style>
</head>
<body>
    <h1>Adicionar Cor Favorita</h1>
    <form method="POST">
        <label for="nome_cor">Nome da Cor:</label>
        <input type="text" name="nome_cor" required>
        <input type="submit" value="Adicionar">
    </form>
    <a href="index.php">Voltar</a>
</body>
</html>
